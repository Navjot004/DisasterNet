"use client";
import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";

// Fix Leaflet marker icons
import L from "leaflet";
// @ts-ignore
import iconUrl from "leaflet/dist/images/marker-icon.png";
// @ts-ignore
import iconShadow from "leaflet/dist/images/marker-shadow.png";

let DefaultIcon = L.icon({
  iconUrl,
  shadowUrl: iconShadow,
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

interface DisasterEvent {
  id: string;
  title: string;
  magnitude: number;
  coords: [number, number];
  time: string;
}

export const DisasterMap = () => {
  const [events, setEvents] = useState<DisasterEvent[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(
          "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojson"
        );
        const data = await res.json();

        const eqEvents = data.features.map((f: any) => ({
          id: f.id,
          title: f.properties.place,
          magnitude: f.properties.mag,
          coords: [f.geometry.coordinates[1], f.geometry.coordinates[0]], // lat, lng
          time: new Date(f.properties.time).toLocaleString(),
        }));

        setEvents(eqEvents);
      } catch (err) {
        console.error("Error fetching data:", err);
      }
    };

    fetchData();
  }, []);

  return (
    <MapContainer
      center={[20, 0]} // Center on world
      zoom={2}
      scrollWheelZoom={true}
      style={{ height: "100%", width: "100%" }}
    >
      {/* Base Layer */}
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />

      {/* Disaster Markers */}
      {events.map((e) => (
        <Marker key={e.id} position={e.coords}>
          <Popup>
            <strong>🌍 {e.title}</strong> <br />
            Magnitude: {e.magnitude} <br />
            Time: {e.time}
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
};
