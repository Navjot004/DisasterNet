import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Flame, 
  Waves, 
  Mountain, 
  Wind,
  Clock,
  Users,
  ExternalLink
} from "lucide-react";

const recentEvents = [
  {
    id: 1,
    type: "wildfire",
    title: "Massive Wildfire Spreads in Northern California",
    location: "Mendocino County, CA",
    severity: "critical",
    affected: "25,000",
    time: "2 hours ago",
    status: "active"
  },
  {
    id: 2,
    type: "earthquake",
    title: "7.2 Magnitude Earthquake Hits Central Japan",
    location: "Honshu, Japan", 
    severity: "high",
    affected: "150,000",
    time: "45 minutes ago",
    status: "monitoring"
  },
  {
    id: 3,
    type: "flood",
    title: "Flash Floods Due to Heavy Monsoon",
    location: "Kerala, India",
    severity: "medium",
    affected: "80,000",
    time: "3 hours ago",
    status: "response"
  },
  {
    id: 4,
    type: "cyclone",
    title: "Category 3 Hurricane Approaching Coast",
    location: "Gulf of Mexico",
    severity: "high",
    affected: "200,000",
    time: "5 hours ago", 
    status: "warning"
  },
  {
    id: 5,
    type: "earthquake",
    title: "5.8 Magnitude Aftershock Detected",
    location: "Central Turkey",
    severity: "medium",
    affected: "45,000",
    time: "6 hours ago",
    status: "monitoring"
  }
];

const getEventIcon = (type: string) => {
  switch (type) {
    case "wildfire": return Flame;
    case "flood": return Waves;
    case "earthquake": return Mountain;
    case "cyclone": return Wind;
    default: return Mountain;
  }
};

const getSeverityColor = (severity: string) => {
  switch (severity) {
    case "critical": return "text-emergency-critical border-emergency-critical";
    case "high": return "text-emergency-high border-emergency-high";
    case "medium": return "text-emergency-medium border-emergency-medium";
    case "low": return "text-emergency-low border-emergency-low";
    default: return "text-muted-foreground border-border";
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case "active": return "bg-emergency-critical/10 text-emergency-critical";
    case "warning": return "bg-emergency-high/10 text-emergency-high";
    case "response": return "bg-emergency-medium/10 text-emergency-medium";
    case "monitoring": return "bg-emergency-info/10 text-emergency-info";
    default: return "bg-muted text-muted-foreground";
  }
};

export const RecentEvents = () => {
  return (
    <ScrollArea className="h-[500px] px-6">
      <div className="space-y-4 py-4">
        {recentEvents.map((event) => {
          const Icon = getEventIcon(event.type);
          
          return (
            <div
              key={event.id}
              className="group border border-card-border rounded-lg p-4 hover:bg-card/50 transition-all duration-200 cursor-pointer animate-slide-in-up"
            >
              <div className="flex items-start gap-3">
                {/* Event Icon */}
                <div className={`
                  rounded-full p-2 flex-shrink-0
                  ${event.severity === "critical" ? "bg-emergency-critical/10" : ""}
                  ${event.severity === "high" ? "bg-emergency-high/10" : ""}
                  ${event.severity === "medium" ? "bg-emergency-medium/10" : ""}
                  ${event.severity === "low" ? "bg-emergency-low/10" : ""}
                `}>
                  <Icon className={`h-4 w-4 ${getSeverityColor(event.severity).split(" ")[0]}`} />
                </div>

                {/* Event Details */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h3 className="text-sm font-medium text-card-foreground leading-tight group-hover:text-primary transition-colors">
                      {event.title}
                    </h3>
                    <Badge variant="outline" className={`${getSeverityColor(event.severity)} text-xs`}>
                      {event.severity}
                    </Badge>
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs text-muted-foreground">{event.location}</p>
                    
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Users className="h-3 w-3" />
                        <span>{event.affected} affected</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        <span>{event.time}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <Badge className={`${getStatusColor(event.status)} text-xs`}>
                        {event.status}
                      </Badge>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-6 px-2 text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        Details
                        <ExternalLink className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </ScrollArea>
  );
};