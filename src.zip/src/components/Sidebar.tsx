import { NavLink } from "react-router-dom";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Calendar, 
  Brain, 
  Truck, 
  BarChart3, 
  Bell,
  Shield,
  Activity
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard },
  { name: "Events", href: "/events", icon: Calendar },
  { name: "AI Prediction", href: "/prediction", icon: Brain },
  { name: "Resources", href: "/resources", icon: Truck },
  { name: "Analytics", href: "/analytics", icon: BarChart3 },
  { name: "Alerts", href: "/alerts", icon: Bell },
];

export const Sidebar = () => {
  return (
    <div className="fixed inset-y-0 left-0 z-50 w-64 bg-sidebar border-r border-sidebar-border lg:block hidden">
      <div className="flex h-full flex-col">
        {/* Logo and Brand */}
        <div className="flex h-16 items-center gap-3 px-6 border-b border-sidebar-border">
          <div className="relative">
            <Shield className="h-8 w-8 text-emergency-critical animate-glow" />
            <Activity className="absolute -top-1 -right-1 h-4 w-4 text-emergency-info animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-sidebar-foreground">DisasterNet</h1>
            <p className="text-xs text-sidebar-foreground/60">AI Response Platform</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-1 p-4">
          {navigation.map((item) => (
            <NavLink
              key={item.name}
              to={item.href}
              className={({ isActive }) =>
                cn(
                  "group flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200",
                  isActive
                    ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-md"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                )
              }
            >
              <item.icon className="h-5 w-5 shrink-0" />
              {item.name}
            </NavLink>
          ))}
        </nav>

        {/* Status Footer */}
        <div className="border-t border-sidebar-border p-4">
          <div className="rounded-lg bg-sidebar-accent p-3">
            <div className="flex items-center gap-2 mb-2">
              <div className="h-2 w-2 rounded-full bg-emergency-low animate-pulse"></div>
              <span className="text-xs font-medium text-sidebar-foreground">System Status</span>
            </div>
            <p className="text-xs text-sidebar-foreground/70">All systems operational</p>
            <p className="text-xs text-sidebar-foreground/50 mt-1">Last updated: 2 min ago</p>
          </div>
        </div>
      </div>
    </div>
  );
};