import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string;
  change: string;
  icon: LucideIcon;
  trend: "up" | "down" | "stable";
  severity: "critical" | "high" | "medium" | "low" | "info";
}

export const StatsCard = ({ 
  title, 
  value, 
  change, 
  icon: Icon, 
  trend,
  severity 
}: StatsCardProps) => {
  const severityColors = {
    critical: "text-emergency-critical",
    high: "text-emergency-high", 
    medium: "text-emergency-medium",
    low: "text-emergency-low",
    info: "text-emergency-info"
  };

  const severityBg = {
    critical: "bg-emergency-critical/10",
    high: "bg-emergency-high/10",
    medium: "bg-emergency-medium/10", 
    low: "bg-emergency-low/10",
    info: "bg-emergency-info/10"
  };

  return (
    <Card className="p-6 border-card-border bg-card animate-scale-in">
      <div className="flex items-center justify-between mb-4">
        <div className={cn(
          "rounded-lg p-3",
          severityBg[severity]
        )}>
          <Icon className={cn("h-6 w-6", severityColors[severity])} />
        </div>
        <div className={cn(
          "text-xs px-2 py-1 rounded-full",
          trend === "up" && "bg-emergency-high/10 text-emergency-high",
          trend === "down" && "bg-emergency-low/10 text-emergency-low", 
          trend === "stable" && "bg-muted text-muted-foreground"
        )}>
          {trend === "up" && "↑"}
          {trend === "down" && "↓"}
          {trend === "stable" && "→"}
        </div>
      </div>
      
      <div className="space-y-2">
        <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
        <div className="text-2xl font-bold text-card-foreground">{value}</div>
        <p className="text-xs text-muted-foreground">{change}</p>
      </div>
    </Card>
  );
};